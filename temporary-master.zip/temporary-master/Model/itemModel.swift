//
//  itemModel.swift
//  FindThings
//
//  Created by Gaurav Amrutiya on 15/06/18.
//  Copyright © 2018 Gaurav Amrutiya. All rights reserved.
//

import Foundation

class itemModel {
    
    let itemName:String
    let storedArr:NSArray
    let attributesArr:NSArray
    
    init(name:String,storedAt:NSArray,attributes:NSArray) {
        itemName=name
        storedArr=storedAt
        attributesArr=attributes
    }
}

